#! /bin/bash
sleep 3
echo -e "\n----->Start updater <-----\n"
updater -d -f